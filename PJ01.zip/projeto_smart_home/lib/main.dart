import 'package:flutter/material.dart';
import 'package:flutter_application_2/pages/button_page.dart';
import 'package:flutter_application_2/pages/cad_user.dart';
import 'package:flutter_application_2/pages/login.dart';
import 'package:flutter_application_2/pages/temperatura.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JR_SMART_HOME',
      initialRoute: 'login',
      routes: {
        'home' :(context) => const ButtonPage(),
        'login' :(context) => const TelaLogin(),
        'cadUser' :(context) => const CadUser(),
        'temperatura' :(context) => const Temperatura(),
      },
      theme: ThemeData(
        brightness: Brightness.dark,        
      ),
      //home: const ButtonPage(),
    );
  }
}

