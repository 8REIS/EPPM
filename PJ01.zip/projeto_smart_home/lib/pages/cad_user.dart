import 'package:flutter/material.dart';

class CadUser extends StatefulWidget {
  const CadUser({ Key? key }) : super(key: key);

  @override
  State<CadUser> createState() => _CadUserState();
}

class _CadUserState extends State<CadUser> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //BARRA TÍTULO
      appBar: AppBar(         
        title: const Text('CADASTRO DE USUÁRIO'),
        centerTitle: true,
        backgroundColor: Colors.lightBlue.shade900,
      ),
     
      
    );
  }
}