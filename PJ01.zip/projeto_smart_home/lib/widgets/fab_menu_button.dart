import 'package:flutter/material.dart';
import 'package:flutter_application_2/delegates/fab_vertical_delegate.dart';

class FabMenuButton extends StatefulWidget {
  const FabMenuButton({ Key? key }) : super(key: key);

  @override
  State<FabMenuButton> createState() => _FabMenuButtonState();
}

class _FabMenuButtonState extends State<FabMenuButton>with SingleTickerProviderStateMixin {
  final actionButtonColor = Colors.tealAccent.shade100;
  late AnimationController animation;
  final menuIsOpen = ValueNotifier<bool>(false);

  @override
  void initState(){
  super.initState();
  animation = AnimationController(vsync: this, duration: const Duration(milliseconds: 250));
  }

  @override
  void dispose(){
    animation.dispose();
    super.dispose();
  }

  toggMenu(){
    menuIsOpen.value ? animation.reverse() : animation.forward();
    menuIsOpen.value =! menuIsOpen.value;
  }

   @override
  Widget build(BuildContext context) {
    return Flow(
      clipBehavior: Clip.none,
      delegate:  FabVerticalDelegate(animation: animation),
      children: [
        FloatingActionButton(
        child:  AnimatedIcon(
          icon: AnimatedIcons.menu_close,
          progress: animation,
        ),
        onPressed: () => toggMenu(),
        backgroundColor: actionButtonColor,
       ),

       FloatingActionButton(
        child: const Icon(Icons.camera_alt_rounded),
        onPressed: (){},
        backgroundColor: actionButtonColor,
       ),

       FloatingActionButton(
        child: const Icon(Icons.link),
        onPressed: (){},
        backgroundColor: actionButtonColor,
       ),

       FloatingActionButton(
        child: const Icon(Icons.block_flipped),
        onPressed: (){},
        backgroundColor: actionButtonColor,
       ),

       FloatingActionButton(
        child: const Icon(Icons.admin_panel_settings),
        onPressed: (){},
        backgroundColor: actionButtonColor,
       ),

       FloatingActionButton(
        child: const Icon(Icons.sensors),
        onPressed: (){
          Navigator.pushNamed(context, 'temperatura');
        },
        backgroundColor: actionButtonColor,
       ),
      ],
); 
     
  }
}